﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using EditorUML.Model;

namespace EditorUML
{
    public partial class FieldDialog : Form
    {
        FieldModel model;

        public FieldDialog(FieldModel m)
        {
            InitializeComponent();
            model = m;
            textBox2.Text = model.Identifier;
            textTypeField.Text = model.Type;
            comboBox1.SelectedItem = comboBox1.Items[0];
        }

        private void CreateField_Click(object sender, EventArgs e)
        {
            if (textBox2.Text == "" || textTypeField.Text == "")
            {
                MessageBox.Show("Field name and type are mandatory.", "Error",
                            MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
            else
            {
                DialogResult = DialogResult.OK;

                model.Identifier = textBox2.Text;
                model.Type = textTypeField.Text;
                model.FieldModifier = comboBox1.Text;
                           
                Close();
            }
        }

        private void CancelField_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.Cancel;
            Close();
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void textTypeField_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
