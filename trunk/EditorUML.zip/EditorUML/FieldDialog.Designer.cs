﻿namespace EditorUML
{
    partial class FieldDialog
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.textTypeField = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.CreateField = new System.Windows.Forms.Button();
            this.CancelField = new System.Windows.Forms.Button();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(48, 26);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(34, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Type:";
            // 
            // textTypeField
            // 
            this.textTypeField.Location = new System.Drawing.Point(154, 23);
            this.textTypeField.Name = "textTypeField";
            this.textTypeField.Size = new System.Drawing.Size(192, 20);
            this.textTypeField.TabIndex = 1;
            this.textTypeField.TextChanged += new System.EventHandler(this.textTypeField_TextChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(48, 69);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(50, 13);
            this.label2.TabIndex = 2;
            this.label2.Text = "Identifier:";
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(155, 66);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(190, 20);
            this.textBox2.TabIndex = 3;
            this.textBox2.TextChanged += new System.EventHandler(this.textBox2_TextChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(48, 111);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(82, 13);
            this.label3.TabIndex = 4;
            this.label3.Text = "AccessModifier:";
            // 
            // CreateField
            // 
            this.CreateField.Location = new System.Drawing.Point(116, 193);
            this.CreateField.Name = "CreateField";
            this.CreateField.Size = new System.Drawing.Size(94, 25);
            this.CreateField.TabIndex = 6;
            this.CreateField.Text = "Create";
            this.CreateField.UseVisualStyleBackColor = true;
            this.CreateField.Click += new System.EventHandler(this.CreateField_Click);
            // 
            // CancelField
            // 
            this.CancelField.Location = new System.Drawing.Point(255, 194);
            this.CancelField.Name = "CancelField";
            this.CancelField.Size = new System.Drawing.Size(91, 23);
            this.CancelField.TabIndex = 7;
            this.CancelField.Text = "Cancel";
            this.CancelField.UseVisualStyleBackColor = true;
            this.CancelField.Click += new System.EventHandler(this.CancelField_Click);
            // 
            // comboBox1
            // 
            this.comboBox1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "public",
            "protected",
            "private"});
            this.comboBox1.Location = new System.Drawing.Point(154, 108);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(192, 21);
            this.comboBox1.TabIndex = 8;
            // 
            // FieldDialog
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(401, 259);
            this.Controls.Add(this.comboBox1);
            this.Controls.Add(this.CancelField);
            this.Controls.Add(this.CreateField);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.textTypeField);
            this.Controls.Add(this.label1);
            this.Name = "FieldDialog";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "FieldDialog";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textTypeField;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button CreateField;
        private System.Windows.Forms.Button CancelField;
        private System.Windows.Forms.ComboBox comboBox1;
    }
}