﻿using System;
using System.Drawing;


namespace EditorUML.Math
{
    public enum IntersectResult { PARALLEL, COINCIDENT, NOT_INTERESECTING, INTERESECTING }

    public class LineSegment
    {
        public PointF begin_;
        public PointF end_;

        public LineSegment(PointF begin, PointF end)
        {
            begin_ = begin;
            end_ = end;
        }

        public IntersectResult Intersect(LineSegment other_line, ref PointF intersection)
        {
            float denom = ((other_line.end_.Y - other_line.begin_.Y) * (end_.X - begin_.X)) -
                          ((other_line.end_.X - other_line.begin_.X) * (end_.Y - begin_.Y));

            float nume_a = ((other_line.end_.X - other_line.begin_.X) * (begin_.Y - other_line.begin_.Y)) -
                           ((other_line.end_.Y - other_line.begin_.Y) * (begin_.X - other_line.begin_.X));

            float nume_b = ((end_.X - begin_.X) * (begin_.Y - other_line.begin_.Y)) -
                           ((end_.Y - begin_.Y) * (begin_.X - other_line.begin_.X));

            if (denom == 0.0f)
            {
                if (nume_a == 0.0f && nume_b == 0.0f)
                {
                    return IntersectResult.COINCIDENT;
                }
                return IntersectResult.PARALLEL;
            }

            float ua = nume_a / denom;
            float ub = nume_b / denom;

            if (ua >= 0.0f && ua <= 1.0f && ub >= 0.0f && ub <= 1.0f)
            {
                // Get the intersection point.
                intersection.X = begin_.X + ua * (end_.X - begin_.X);
                intersection.Y = begin_.Y + ua * (end_.Y - begin_.Y);

                return IntersectResult.INTERESECTING;
            }

            return IntersectResult.NOT_INTERESECTING;
        }
    }

    public class RectSegIntersection
    {

        public PointF TopLeft;
        public PointF BottomRight;

        public RectSegIntersection(PointF topLeft, PointF bottomRight)
        {
            TopLeft = topLeft;
            BottomRight = bottomRight;
        }

        public IntersectResult IntersectWithSegment(PointF p1, PointF p2, ref PointF intersection)
        {
            LineSegment dreapta = new LineSegment(p1, p2);

            // rectangle are 4 segmente
            // vom testa intersectia dintre segmentul {P1,P2} cu fiecare latura
            //
            //    TopLeft(x,y)    a   
            //        |--------------------------|
            //        |                          |   
            //      b |                          | d
            //        |                          |
            //        |--------------------------|
            //                    c          BottomRight(x,y)

            LineSegment a = new LineSegment(TopLeft, new PointF(BottomRight.X, TopLeft.Y));
            LineSegment b = new LineSegment(TopLeft, new PointF(TopLeft.X, BottomRight.Y));
            LineSegment c = new LineSegment(new PointF(TopLeft.X, BottomRight.Y), BottomRight);
            LineSegment d = new LineSegment(new PointF(BottomRight.X, TopLeft.Y), BottomRight);

            if (a.Intersect(dreapta, ref intersection) == IntersectResult.INTERESECTING)
                return IntersectResult.INTERESECTING;
            if (b.Intersect(dreapta, ref intersection) == IntersectResult.INTERESECTING)
                return IntersectResult.INTERESECTING;
            if (c.Intersect(dreapta, ref intersection) == IntersectResult.INTERESECTING)
                return IntersectResult.INTERESECTING;
            if (d.Intersect(dreapta, ref intersection) == IntersectResult.INTERESECTING)
                return IntersectResult.INTERESECTING;

            return IntersectResult.NOT_INTERESECTING;
        }


    }
}
