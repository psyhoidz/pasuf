﻿namespace EditorUML.Dialogs
{
    partial class ClassDialog
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.textBoxClassName = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.Fields = new System.Windows.Forms.TabPage();
            this.button6 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.listBoxFields = new System.Windows.Forms.ListBox();
            this.Methods = new System.Windows.Forms.TabPage();
            this.DownMethodsB = new System.Windows.Forms.Button();
            this.UpMethodsB = new System.Windows.Forms.Button();
            this.EditMethodsB = new System.Windows.Forms.Button();
            this.DeleteMethodsB = new System.Windows.Forms.Button();
            this.CreateMethodsB = new System.Windows.Forms.Button();
            this.listBoxMethods = new System.Windows.Forms.ListBox();
            this.tabControl1.SuspendLayout();
            this.Fields.SuspendLayout();
            this.Methods.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(14, 16);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(66, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Class Name:";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // textBoxClassName
            // 
            this.textBoxClassName.Location = new System.Drawing.Point(86, 13);
            this.textBoxClassName.Name = "textBoxClassName";
            this.textBoxClassName.Size = new System.Drawing.Size(213, 20);
            this.textBoxClassName.TabIndex = 1;
            // 
            // button1
            // 
            this.button1.DialogResult = System.Windows.Forms.DialogResult.OK;
            this.button1.Location = new System.Drawing.Point(486, 403);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 2;
            this.button1.Text = "Create Class";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.button2.Location = new System.Drawing.Point(578, 403);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 23);
            this.button2.TabIndex = 3;
            this.button2.Text = "Cancel";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.Fields);
            this.tabControl1.Controls.Add(this.Methods);
            this.tabControl1.Location = new System.Drawing.Point(17, 70);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(636, 311);
            this.tabControl1.TabIndex = 4;
            // 
            // Fields
            // 
            this.Fields.Controls.Add(this.button6);
            this.Fields.Controls.Add(this.button5);
            this.Fields.Controls.Add(this.button4);
            this.Fields.Controls.Add(this.button3);
            this.Fields.Controls.Add(this.listBoxFields);
            this.Fields.Location = new System.Drawing.Point(4, 22);
            this.Fields.Name = "Fields";
            this.Fields.Padding = new System.Windows.Forms.Padding(3);
            this.Fields.Size = new System.Drawing.Size(628, 285);
            this.Fields.TabIndex = 0;
            this.Fields.Text = "Fields";
            this.Fields.UseVisualStyleBackColor = true;
            // 
            // button6
            // 
            this.button6.Location = new System.Drawing.Point(547, 97);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(75, 23);
            this.button6.TabIndex = 4;
            this.button6.Text = "Down";
            this.button6.UseVisualStyleBackColor = true;
            // 
            // button5
            // 
            this.button5.Location = new System.Drawing.Point(546, 67);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(75, 23);
            this.button5.TabIndex = 3;
            this.button5.Text = "Up";
            this.button5.UseVisualStyleBackColor = true;
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(547, 37);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(75, 23);
            this.button4.TabIndex = 2;
            this.button4.Text = "Delete Field";
            this.button4.UseVisualStyleBackColor = true;
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(546, 7);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(75, 23);
            this.button3.TabIndex = 1;
            this.button3.Text = "Create Field";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // listBoxFields
            // 
            this.listBoxFields.FormattingEnabled = true;
            this.listBoxFields.Location = new System.Drawing.Point(7, 7);
            this.listBoxFields.Name = "listBoxFields";
            this.listBoxFields.Size = new System.Drawing.Size(533, 264);
            this.listBoxFields.TabIndex = 0;
            // 
            // Methods
            // 
            this.Methods.Controls.Add(this.DownMethodsB);
            this.Methods.Controls.Add(this.UpMethodsB);
            this.Methods.Controls.Add(this.EditMethodsB);
            this.Methods.Controls.Add(this.DeleteMethodsB);
            this.Methods.Controls.Add(this.CreateMethodsB);
            this.Methods.Controls.Add(this.listBoxMethods);
            this.Methods.Location = new System.Drawing.Point(4, 22);
            this.Methods.Name = "Methods";
            this.Methods.Padding = new System.Windows.Forms.Padding(3);
            this.Methods.Size = new System.Drawing.Size(628, 285);
            this.Methods.TabIndex = 1;
            this.Methods.Text = "Methods";
            this.Methods.UseVisualStyleBackColor = true;
            // 
            // DownMethodsB
            // 
            this.DownMethodsB.Location = new System.Drawing.Point(535, 181);
            this.DownMethodsB.Name = "DownMethodsB";
            this.DownMethodsB.Size = new System.Drawing.Size(63, 23);
            this.DownMethodsB.TabIndex = 5;
            this.DownMethodsB.Text = "Down";
            this.DownMethodsB.UseVisualStyleBackColor = true;
            // 
            // UpMethodsB
            // 
            this.UpMethodsB.Location = new System.Drawing.Point(535, 145);
            this.UpMethodsB.Name = "UpMethodsB";
            this.UpMethodsB.Size = new System.Drawing.Size(63, 21);
            this.UpMethodsB.TabIndex = 4;
            this.UpMethodsB.Text = "Up";
            this.UpMethodsB.UseVisualStyleBackColor = true;
            // 
            // EditMethodsB
            // 
            this.EditMethodsB.Location = new System.Drawing.Point(535, 104);
            this.EditMethodsB.Name = "EditMethodsB";
            this.EditMethodsB.Size = new System.Drawing.Size(64, 21);
            this.EditMethodsB.TabIndex = 3;
            this.EditMethodsB.Text = "Edit";
            this.EditMethodsB.UseVisualStyleBackColor = true;
            // 
            // DeleteMethodsB
            // 
            this.DeleteMethodsB.Location = new System.Drawing.Point(535, 64);
            this.DeleteMethodsB.Name = "DeleteMethodsB";
            this.DeleteMethodsB.Size = new System.Drawing.Size(63, 20);
            this.DeleteMethodsB.TabIndex = 2;
            this.DeleteMethodsB.Text = "Delete Method";
            this.DeleteMethodsB.UseVisualStyleBackColor = true;
            // 
            // CreateMethodsB
            // 
            this.CreateMethodsB.Location = new System.Drawing.Point(535, 26);
            this.CreateMethodsB.Name = "CreateMethodsB";
            this.CreateMethodsB.Size = new System.Drawing.Size(63, 20);
            this.CreateMethodsB.TabIndex = 1;
            this.CreateMethodsB.Text = "Create Method";
            this.CreateMethodsB.UseVisualStyleBackColor = true;
            this.CreateMethodsB.Click += new System.EventHandler(this.CreateMethodsB_Click);
            // 
            // listBoxMethods
            // 
            this.listBoxMethods.FormattingEnabled = true;
            this.listBoxMethods.Location = new System.Drawing.Point(9, 16);
            this.listBoxMethods.Name = "listBoxMethods";
            this.listBoxMethods.Size = new System.Drawing.Size(487, 225);
            this.listBoxMethods.TabIndex = 0;
            this.listBoxMethods.SelectedIndexChanged += new System.EventHandler(this.listBoxMethods_SelectedIndexChanged);
            // 
            // ClassDialog
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(671, 438);
            this.Controls.Add(this.tabControl1);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.textBoxClassName);
            this.Controls.Add(this.label1);
            this.Name = "ClassDialog";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "ClassDialog";
            this.tabControl1.ResumeLayout(false);
            this.Fields.ResumeLayout(false);
            this.Methods.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textBoxClassName;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage Fields;
        private System.Windows.Forms.TabPage Methods;
        private System.Windows.Forms.ListBox listBoxFields;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button DeleteMethodsB;
        private System.Windows.Forms.Button CreateMethodsB;
        private System.Windows.Forms.ListBox listBoxMethods;
        private System.Windows.Forms.Button DownMethodsB;
        private System.Windows.Forms.Button UpMethodsB;
        private System.Windows.Forms.Button EditMethodsB;
    }
}