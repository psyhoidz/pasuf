﻿using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Collections.Generic;
using System.IO;
using EditorUML.Model;
using EditorUML.Math;

namespace EditorUML.Graphic
{
    abstract public class GraphicDrawer
    {
        public bool selected;
        public virtual void Draw(Graphics g) {}
        public virtual bool HitTest(Point point) { return false; }
        public virtual void WriteToFile(StreamWriter sw) { }
        public virtual void Move(int dx, int dy) { }
    }

    public class ClassGraphicDrawer : GraphicDrawer
    {
        public ClassModel model;
        
        public int x;
        public int y;
        public int width;
        public int height;

        public ClassGraphicDrawer(ClassModel m, int ix, int iy)
        {
            model = m;
            x = ix;
            y = iy;
            selected = false;
        }

        public override void Draw(Graphics dc)
        {
            // desenul clasei ( drept, nume clasa, metode, linii)

                Font f = new Font("Verdana", 18);
                string numeClasa = model.ClassName;
                int dimRect = numeClasa.Length * (int)f.SizeInPoints*2;//am inmultit cu 2 temporar
                string metoda, camp;
                metoda = "";
                camp = "";

    
                //pozitia si dimensiunea dreptunghiului
                Point RectangleTopLeft = new Point(x, y);
                int nrMetode = (model.Methods.Count + 1) * ((int)f.Size);
                int nrCampuri = (model.Fields.Count + 1) * ((int)f.Size);
                Size RectangleSize = new Size(dimRect, nrMetode+nrCampuri+30);
                
                // de test
                width = dimRect;
                height = nrMetode + nrCampuri + 30;
                
                Pen bluePen = new Pen(Color.Blue, 3);
                Pen redPen = new Pen(Color.Red, 2);
                Rectangle RectangleArea = new Rectangle(RectangleTopLeft, RectangleSize);

                // de test
                if (selected)
                    dc.DrawRectangle(redPen, RectangleArea);
                else
                    dc.DrawRectangle(bluePen, RectangleArea);

                int yf = y;
                

                StringFormat sf = new StringFormat();
                sf.Alignment = StringAlignment.Center;
                dc.DrawString(numeClasa, f, Brushes.Brown, RectangleArea, sf);
                //desenare field-uri in dreptunghiul clasei
                foreach (FieldModel fm in model.Fields)
                {
                    if (fm.FieldModifier.Equals("public"))
                        camp = "+";
                    if (fm.FieldModifier.Equals("private"))
                        camp = "-";
                    if (fm.FieldModifier.Equals("protected"))
                        camp = "#";

                    camp = camp + fm.Identifier.ToString() + " : " + fm.Type.ToString();
                    yf = yf + 24;

                    dc.DrawString(camp, f, Brushes.Brown, x, yf );
                }
                //desenare identificator metoda 
                int ym = yf;
                foreach (MethodModel m in model.Methods)
                {

                    metoda = m.Type.ToString()+"  "+m.Identifier.ToString() + "(..);";
                    ym = ym + 24;                  
                    dc.DrawString(metoda, f, Brushes.Brown, x, ym);
                    
                }

                //desenare linie de dupa numele clasei
                PointF p1 = new PointF();
                PointF p2 = new PointF();
                p1.X = RectangleTopLeft.X;
                p1.Y = RectangleTopLeft.Y + f.GetHeight();
                p2.X = p1.X + RectangleSize.Width;
                p2.Y = p1.Y;

                dc.DrawLine(Pens.Blue, p1, p2);

                //desenare linie dintre campuri si metode
                PointF l1 = new PointF();
                PointF l2 = new PointF();
                l1.X = RectangleTopLeft.X;
                l1.Y = yf+24;
                l2.X = l1.X + RectangleSize.Width;
                l2.Y = yf+24;

                dc.DrawLine(Pens.Blue, l1, l2);
                
        }

        public override void Move(int dx, int dy)
        {
            x += dx;
            y += dy;
        }

        public override bool HitTest(Point point)
        {
            if ((point.X > x && point.X < x + width) &&
                (point.Y > y && point.Y < y + height))
                return true;

            return false;
        }

        public override void WriteToFile(StreamWriter sw)
        {
            sw.WriteLine("public class " + model.ClassName);
            sw.WriteLine("{");
            // Fields
            foreach (FieldModel f in model.Fields)
                sw.WriteLine("  " + f.FieldModifier + " " + f.Type + " " + f.Identifier + ";");

            // Methods
            string prot_type, prot_name, prot_modif;
            prot_type = "";
            prot_name = "";
            prot_modif = "";
            int i;i=0;
            //se formeaza prototipul metodei
            foreach (MethodModel m in model.Methods)
            {
                sw.Write("  " + m.Type + " " + m.Identifier+ "(" );
                foreach (ParameterModel p in m.ParamList)
                {
                    prot_name = p.Identifier;
                    prot_type = p.Type;
                    prot_modif = p.Modif;

                    i++;
                    
                      sw.Write(" "+ prot_modif + " " + prot_type + " " + prot_name);
                    if (i < m.ParamList.Count)
                        sw.Write(",");
                }
                sw.WriteLine(");");
            }

            sw.WriteLine("}");
            sw.WriteLine();
        }
    }


    public class InherintanceGraphicDrawer : GraphicDrawer
    {
        public ClassGraphicDrawer baseClass;
        public ClassGraphicDrawer derivateClass;

        public InherintanceGraphicDrawer(ClassGraphicDrawer b, ClassGraphicDrawer d)
        {
            baseClass = b;
            derivateClass = d;
        }

        public override void Draw(Graphics g) 
        {
            // dreapta (P1,P2) uneste mijloacele dreptunghiurilor
            // calculam mijlocul dreptunghiului clasei de basa si celei derivate
            PointF pIntWithBase = new PointF();
            PointF pIntWithDeriv = new PointF();
            Point p1 = new Point();
            Point p2 = new Point();

            p1.X = baseClass.x + (baseClass.width / 2);
            p1.Y = baseClass.y + (baseClass.height / 2);//punctul de la mijlocul dreptunghiului clasei 1

            p2.X = derivateClass.x + (derivateClass.width / 2);
            p2.Y = derivateClass.y + (derivateClass.height / 2);//punctul de la mijlocul dreptunghiului clasei 2

            RectSegIntersection baseRect = new RectSegIntersection(new PointF(baseClass.x, baseClass.y), new PointF(baseClass.x + baseClass.width, baseClass.y + baseClass.height));
            RectSegIntersection dervRect = new RectSegIntersection(new PointF(derivateClass.x, derivateClass.y), new PointF(derivateClass.x + derivateClass.width, derivateClass.y + derivateClass.height));

            baseRect.IntersectWithSegment(p1, p2, ref pIntWithBase);
            dervRect.IntersectWithSegment(p1, p2, ref pIntWithDeriv);

            Pen capPen = new Pen(Color.Blue);
            capPen.Width = 6;
            capPen.MiterLimit = 100;
            capPen.DashStyle = DashStyle.Solid;

            // Set the start and end caps for capPen.
            capPen.SetLineCap(LineCap.ArrowAnchor, LineCap.Flat, DashCap.Flat);

            GraphicsPath hPath = new GraphicsPath();

            // Create the outline for our custom end cap.
            //hPath.AddLine(new Point(-3, 0), new Point(3, 0));
            //hPath.AddLine(new Point(3, 0), new Point(0, 3));
            //hPath.AddLine(new Point(0, 3), new Point(-3, 0));
            hPath.AddLine(new Point(-3, 0), new Point(3, 0));
            hPath.AddLine(new Point(3, 0), new Point(0, 3));
            hPath.AddLine(new Point(0, 3), new Point(-3, 0));


            // Construct the hook-shaped end cap.
            CustomLineCap HookCap = new CustomLineCap(null, hPath);

            // Set the start cap and end cap of the HookCap to be rounded.
            HookCap.SetStrokeCaps(LineCap.Round, LineCap.Round);

            // Create a pen and set end custom start and end
            // caps to the hook cap.
            Pen customCapPen = new Pen(Color.Black, 3);
            customCapPen.CustomStartCap = HookCap;
            //customCapPen.CustomEndCap = HookCap;


            g.DrawLine(customCapPen, pIntWithBase, pIntWithDeriv);
        }

        public override bool HitTest(Point point) { return false; }


        public override void WriteToFile(StreamWriter sw)
        {

        }
    }

}
