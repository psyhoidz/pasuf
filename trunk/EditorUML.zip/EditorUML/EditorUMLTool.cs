﻿using System;
using System.Drawing;
using System.Windows.Forms;
using EditorUML.Model;
using EditorUML.Dialogs;
using EditorUML.Graphic;

namespace EditorUML.Tool
{
    public abstract class GenericTool
    {
        public virtual void MouseDown(object sender, MouseEventArgs e) { }
        public virtual void MouseUp(object sender, MouseEventArgs e) {}
        public virtual void MouseMove(object sender, MouseEventArgs e) {}
        public virtual void MouseDoubleClick(object sender, MouseEventArgs e) { }
    }

    public class PointerTool : GenericTool
    {
        Point startPoint = new Point();
        bool bMove = false;

        public override void MouseDown(object sender, MouseEventArgs e)
        {
            bool bHit = false;
            foreach ( GraphicDrawer g in (sender as MainForm).listaDeClase)
            {
                Point p = new Point(e.X,e.Y);
                if (g.HitTest(p))
                {
                    bHit = true;
                    GraphicDrawer selectedGraphic = g;
                    selectedGraphic.selected = true;
                    startPoint.X = e.X;
                    startPoint.Y = e.Y;
                    bMove = true;

                    foreach (GraphicDrawer otherGraphic in (sender as MainForm).listaDeClase)
                        if (otherGraphic != selectedGraphic)
                            otherGraphic.selected = false;

                    (sender as MainForm).Invalidate();
                    return;
                }
            }

            if (bHit == false)
            {
                foreach (GraphicDrawer g in (sender as MainForm).listaDeClase)
                    g.selected = false;
                (sender as MainForm).Invalidate();
                return;
            }
        }

        public override void MouseUp(object sender, MouseEventArgs e)
        {
            bMove = false;
        }

        public override void MouseMove(object sender, MouseEventArgs e)
        {
            if ((e.Button == MouseButtons.Left) && bMove)
            {
                foreach (GraphicDrawer g in (sender as MainForm).listaDeClase)
                    if (g.selected == true)
                    {
                        int dx = e.X - startPoint.X;
                        int dy = e.Y - startPoint.Y;
                        g.Move(dx, dy);
                        startPoint.X = e.X;
                        startPoint.Y = e.Y;
                        (sender as MainForm).Invalidate();
                        break;
                    }
            }
        }

        public override void MouseDoubleClick(object sender, MouseEventArgs e) 
        {
            ClassModel selectedClass = null;

            foreach (GraphicDrawer g in (sender as MainForm).listaDeClase)
            {
                Point p = new Point(e.X, e.Y);
                if (g.HitTest(p))
                {
                    selectedClass = (g as ClassGraphicDrawer).model ;
                    break;
                }
            }

            if (selectedClass != null)
            {
                ClassDialog modifyClassDialog = new ClassDialog(selectedClass);
                modifyClassDialog.Show();
            }
        }
    }

    public class ClassTool : GenericTool
    {
        public override void MouseDown(object sender, MouseEventArgs e)
        {
            // Creating a new class
            bool bHit = false;

            foreach(GraphicDrawer g in (sender as MainForm).listaDeClase )
                if (g.HitTest(new Point(e.X, e.Y)))
                {
                    bHit = true;
                    break;
                }

            if ( !bHit ) 
            {
                ClassModel newClass = new ClassModel("Class" + (sender as MainForm).classNumber.ToString());

                ClassDialog newClassDialog = new ClassDialog(newClass);

                if (newClassDialog.ShowDialog() == DialogResult.OK)
                {
                    // cream clasa
                    (sender as MainForm).classNumber++;
                    ClassGraphicDrawer newClassDrawer = new ClassGraphicDrawer(newClass, e.X, e.Y);
                    (sender as MainForm).listaDeClase.Add(newClassDrawer);
                }
                else
                {
                    // 
                    //Text = "CANCEL";
                }

                newClassDialog.Dispose();

                (sender as MainForm).Invalidate();
            }
        }

        public override void MouseUp(object sender, MouseEventArgs e)
        {
            
        }

        public override void MouseMove(object sender, MouseEventArgs e)
        {
            
        }
    }


    public class InheritanceTool : GenericTool
    {
        private bool bFirstClick;
        private ClassGraphicDrawer baseClass;
        private ClassGraphicDrawer derivateClass;

        public InheritanceTool()
        {
            bFirstClick = true;
        }

        public override void MouseDown(object sender, MouseEventArgs e) 
        {
            foreach(GraphicDrawer g in (sender as MainForm).listaDeClase)
                if (g.HitTest(new Point(e.X, e.Y)))
                {
                    if (bFirstClick)
                    {
                        baseClass = (g as ClassGraphicDrawer);
                        bFirstClick = false;
                    }
                    else
                    {
                        derivateClass = (g as ClassGraphicDrawer);
                        bFirstClick = true;

                        InherintanceGraphicDrawer newInheritance = new InherintanceGraphicDrawer(baseClass, derivateClass);
                        (sender as MainForm).listaDeClase.Add(newInheritance);
                        (sender as MainForm).Invalidate();
                    }
                    break;
                }

        }

        public override void MouseUp(object sender, MouseEventArgs e) { }
        public override void MouseMove(object sender, MouseEventArgs e) { }
    }
}