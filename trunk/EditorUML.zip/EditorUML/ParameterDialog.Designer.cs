﻿namespace EditorUML
{
    partial class ParameterDialog
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.ParameterName = new System.Windows.Forms.Label();
            this.ParameterType = new System.Windows.Forms.Label();
            this.paramNameTextBox = new System.Windows.Forms.TextBox();
            this.paramTypeTextBox = new System.Windows.Forms.TextBox();
            this.ParameterModifier = new System.Windows.Forms.Label();
            this.comboBoxModifier = new System.Windows.Forms.ComboBox();
            this.CreateParamB = new System.Windows.Forms.Button();
            this.CancelParamB = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // ParameterName
            // 
            this.ParameterName.AutoSize = true;
            this.ParameterName.Location = new System.Drawing.Point(27, 39);
            this.ParameterName.Name = "ParameterName";
            this.ParameterName.Size = new System.Drawing.Size(89, 13);
            this.ParameterName.TabIndex = 0;
            this.ParameterName.Text = "Parameter Name:";
            // 
            // ParameterType
            // 
            this.ParameterType.AutoSize = true;
            this.ParameterType.Location = new System.Drawing.Point(30, 90);
            this.ParameterType.Name = "ParameterType";
            this.ParameterType.Size = new System.Drawing.Size(85, 13);
            this.ParameterType.TabIndex = 1;
            this.ParameterType.Text = "Parameter Type:";
            // 
            // paramNameTextBox
            // 
            this.paramNameTextBox.Location = new System.Drawing.Point(144, 36);
            this.paramNameTextBox.Name = "paramNameTextBox";
            this.paramNameTextBox.Size = new System.Drawing.Size(137, 20);
            this.paramNameTextBox.TabIndex = 2;
            this.paramNameTextBox.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // paramTypeTextBox
            // 
            this.paramTypeTextBox.Location = new System.Drawing.Point(145, 87);
            this.paramTypeTextBox.Name = "paramTypeTextBox";
            this.paramTypeTextBox.Size = new System.Drawing.Size(136, 20);
            this.paramTypeTextBox.TabIndex = 3;
            this.paramTypeTextBox.TextChanged += new System.EventHandler(this.paramTypeTextBox_TextChanged);
            // 
            // ParameterModifier
            // 
            this.ParameterModifier.AutoSize = true;
            this.ParameterModifier.Location = new System.Drawing.Point(31, 143);
            this.ParameterModifier.Name = "ParameterModifier";
            this.ParameterModifier.Size = new System.Drawing.Size(47, 13);
            this.ParameterModifier.TabIndex = 4;
            this.ParameterModifier.Text = "Modifier:";
            // 
            // comboBoxModifier
            // 
            this.comboBoxModifier.FormattingEnabled = true;
            this.comboBoxModifier.Items.AddRange(new object[] {
            "in",
            "out",
            "ref"});
            this.comboBoxModifier.Location = new System.Drawing.Point(144, 140);
            this.comboBoxModifier.Name = "comboBoxModifier";
            this.comboBoxModifier.Size = new System.Drawing.Size(137, 21);
            this.comboBoxModifier.TabIndex = 5;
            this.comboBoxModifier.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // CreateParamB
            // 
            this.CreateParamB.Location = new System.Drawing.Point(121, 214);
            this.CreateParamB.Name = "CreateParamB";
            this.CreateParamB.Size = new System.Drawing.Size(109, 21);
            this.CreateParamB.TabIndex = 6;
            this.CreateParamB.Text = "Create Parameter";
            this.CreateParamB.UseVisualStyleBackColor = true;
            this.CreateParamB.Click += new System.EventHandler(this.CreateParamB_Click);
            // 
            // CancelParamB
            // 
            this.CancelParamB.Location = new System.Drawing.Point(270, 214);
            this.CancelParamB.Name = "CancelParamB";
            this.CancelParamB.Size = new System.Drawing.Size(104, 20);
            this.CancelParamB.TabIndex = 7;
            this.CancelParamB.Text = "Cancel";
            this.CancelParamB.UseVisualStyleBackColor = true;
            this.CancelParamB.Click += new System.EventHandler(this.CancelParamB_Click);
            // 
            // ParameterDialog
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(424, 261);
            this.Controls.Add(this.CancelParamB);
            this.Controls.Add(this.CreateParamB);
            this.Controls.Add(this.comboBoxModifier);
            this.Controls.Add(this.ParameterModifier);
            this.Controls.Add(this.paramTypeTextBox);
            this.Controls.Add(this.paramNameTextBox);
            this.Controls.Add(this.ParameterType);
            this.Controls.Add(this.ParameterName);
            this.Name = "ParameterDialog";
            this.Text = "ParameterDialog";
            this.Load += new System.EventHandler(this.ParameterDialog_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label ParameterName;
        private System.Windows.Forms.Label ParameterType;
        private System.Windows.Forms.TextBox paramNameTextBox;
        private System.Windows.Forms.TextBox paramTypeTextBox;
        private System.Windows.Forms.Label ParameterModifier;
        private System.Windows.Forms.ComboBox comboBoxModifier;
        private System.Windows.Forms.Button CreateParamB;
        private System.Windows.Forms.Button CancelParamB;
    }
}