﻿using System;
using System.Collections.Generic;

namespace EditorUML.Model
{
    public class ClassModel
    {
        string className;
        List<FieldModel> fields;
        List<MethodModel> methods;

        public ClassModel(string name)
        {
            ClassName = name;
            Fields = new List<FieldModel>();
            Methods = new List<MethodModel>();

        }

        public string ClassName
        {
            set
            {
                className = value;
            }
            get
            {
                return className;
            }
        }

        public List<FieldModel> Fields
        {
            set { fields = value; }
            get { return fields; }
        }

        public List<MethodModel> Methods
        {
            set { methods = value; }
            get { return methods; }
        }
    }

    public class FieldModel
    {
         string type;
         string identifier;
         string modif;

        public string Type
        {
            set { type = value; }
            get { return type;  }
        }

        public string Identifier
        {
            set { identifier = value; }
            get { return identifier; }
        }

        public FieldModel(string iden)
        {
            Identifier = iden;
        }
        public string FieldModifier
        {
            set
            {
                modif = value;

            }
            get
            {
                return modif;
            }
        }

    }

    public class MethodModel
    {
        string methodName;
        List<ParameterModel> parameters;//lista de parametri interna
        string methodType;
        

        public string Identifier
        {
            set
            {
                methodName = value;
            }
            get
            {
                return methodName;
            }
        }
        public string Type
        {
            set
            {
                methodType = value;
            }
            get
            {
                return methodType;
            }
        }
 

        public MethodModel(string name)
        {
            methodName = name;
            ParamList = new List<ParameterModel>();
            
        }

        public List<ParameterModel> ParamList
        {
            set 
            { 
                parameters = value; 
            }
            get 
            { 
                return parameters; 
            }
        }

    }

    public class ParameterModel
    {
        
        string parameterName;
        string parameterType;
        string parameterModif;

        public string Identifier//mi-am facut eu o proprietate
        {
            set
            {
                parameterName = value;
            }
            get
            {
                return parameterName;
            }
        }

        public string Type
        {
            set
            {
                parameterType = value;
            }
            get
            {
                return parameterType;
            }
        }

        public string Modif
        {
            set
            {
                parameterModif = value;
            }
            get
            {
                return parameterModif;
            }
        }

         public ParameterModel(string param)// 
        {
            parameterName = param;
        }


    }

    //public enum E_AccessModifier
    //{
    //    Public,
    //    Protected,
    //    Private
    //}
    //public enum E_ParameterModifier
    //{
    //    In,
    //    Out,
    //    Ref
    //}
}
