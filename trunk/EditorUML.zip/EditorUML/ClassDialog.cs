﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using EditorUML.Model;

namespace EditorUML.Dialogs
{
    public partial class ClassDialog : Form
    {
        private ClassModel model;

        public ClassDialog(ClassModel classModel)
        {
            model = classModel;

            InitializeComponent();
            textBoxClassName.Text = model.ClassName;
            
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            model.ClassName = textBoxClassName.Text;
            Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            FieldModel newField = new FieldModel("Field" + model.Fields.Count().ToString() );

            FieldDialog newFieldDialog = new FieldDialog(newField);
            if (newFieldDialog.ShowDialog() == DialogResult.OK)
            {
                model.Fields.Add(newField);//mi-am adaugat campul la lista de field-uri a lui ClassModel
            }
            else
            {
 
            }

            listBoxFields.Items.Clear();
            foreach (FieldModel f in model.Fields)
                listBoxFields.Items.Add(f.Identifier.ToString());

            newFieldDialog.Dispose();
        }

        private void CreateMethodsB_Click(object sender, EventArgs e)
        {
            MethodModel newMethod = new MethodModel("Method"+model.Methods.Count().ToString());

            MethodDialog newMethodDialog = new MethodDialog(newMethod);
            if (newMethodDialog.ShowDialog() == DialogResult.OK)
            {
                // cream clasa

                model.Methods.Add(newMethod);
            }
            else
            {

            }
            listBoxMethods.Items.Clear();
            foreach (MethodModel m in model.Methods)
                listBoxMethods.Items.Add(m.Identifier.ToString());

            newMethodDialog.Dispose();
        }

        private void listBoxMethods_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
