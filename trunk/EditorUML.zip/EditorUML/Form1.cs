﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Linq;
using System.Text;
using System.IO;
using System.Windows.Forms;
using EditorUML.Model;
using EditorUML.Dialogs;
using EditorUML.Graphic;
using EditorUML.Tool;

namespace EditorUML
{
    public partial class MainForm : Form
    {
        private GenericTool activeTool;
        public int classNumber = 1;
        public List<GraphicDrawer> listaDeClase;

        public MainForm()
        {
            InitializeComponent();
            listaDeClase = new List<GraphicDrawer>();
            activeTool = new PointerTool();
            toolStripButton4.Checked = true;
        }
    
        private void toolStripButton1_Click(object sender, EventArgs e)
        {

        }

        private void toolStripLabel3_Click(object sender, EventArgs e)
        {
            //
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void Form1_MouseDown(object sender, MouseEventArgs e)
        {
            activeTool.MouseDown(this, e);
        }

        private void toolStripButton1_Click_1(object sender, EventArgs e)
        {
            toolStripButton1.Checked = true;
            toolStripButton2.Checked = false;
            toolStripButton3.Checked = false;
            toolStripButton4.Checked = false;

            // selectie mod crearea clase
            // referinta catre obiectul ClassTool tocmai creat
            activeTool = new ClassTool();
        }

        protected override void  OnPaint(PaintEventArgs e)
        {
            e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;

            foreach (GraphicDrawer c in listaDeClase)
                c.Draw(e.Graphics);
 	        base.OnPaint(e);
        }

        private void MainForm_MouseMove(object sender, MouseEventArgs e)
        {
            //
            activeTool.MouseMove(this, e);
        }

        private void MainForm_MouseUp(object sender, MouseEventArgs e)
        {
            activeTool.MouseUp(this, e);
        }

        private void toolStripButton2_Click(object sender, EventArgs e)
        {
            toolStripButton1.Checked = false;
            toolStripButton2.Checked = true;
            toolStripButton3.Checked = false;
            toolStripButton4.Checked = false;

            activeTool = new InheritanceTool();
        }

        private void toolStripButton3_Click(object sender, EventArgs e)
        {

            toolStripButton1.Checked = false;
            toolStripButton2.Checked = false;
            toolStripButton3.Checked = true;
            toolStripButton4.Checked = false;

            activeTool = new PointerTool();
        }

        private void toolStripButton4_Click(object sender, EventArgs e)
        {
            toolStripButton1.Checked = false;
            toolStripButton2.Checked = false;
            toolStripButton3.Checked = false;
            toolStripButton4.Checked = true;

            activeTool = new PointerTool();
        }

        private void toolStripGenerate_Click(object sender, EventArgs e)
        {
            StreamWriter sw;
            sw = File.CreateText("c:\\MyTextFile.txt");
            sw.WriteLine("===========================");
            sw.WriteLine("Generated code by UMLEditor");
            sw.WriteLine("===========================");
            sw.WriteLine();

            foreach (GraphicDrawer c in listaDeClase)
                c.WriteToFile(sw);

            sw.Close();
            MessageBox.Show("The code was generated in C:\\MyTextFile", "Generation",MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void MainForm_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            activeTool.MouseDoubleClick(this, e);
        }


    }
}
