﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using EditorUML.Model;

namespace EditorUML
{
    public partial class MethodDialog : Form
    {
        private MethodModel model;
        //List<ParameterModel> listaDeParametri;

        public MethodDialog(MethodModel methodModel)
        {
            InitializeComponent();
            model = methodModel;
            //listaDeParametri = new List<ParameterModel>();
            textBox1.Text = model.Identifier;
            textTypeMethod.Text = model.Type;
        }

        private void CreateMethod_Click(object sender, EventArgs e)
        {
             if (textBox1.Text == "" || textTypeMethod.Text == "")
            {
                MessageBox.Show("Name and returned type are mandatory.", "Error",
                            MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
            else
            {
                DialogResult = DialogResult.OK;

                model.Identifier = textBox1.Text;
                model.Type = textTypeMethod.Text;

                Close();
            }

        }

        private void CancelMethod_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void AddParameter_Click(object sender, EventArgs e)
        {
            ParameterModel newParam = new ParameterModel("Param"+model.ParamList.Count().ToString());// pasul 1, fac un nou model

            ParameterDialog newParameterDialog = new ParameterDialog(newParam);


            
            if (newParameterDialog.ShowDialog() == DialogResult.OK)
            {
                model.ParamList.Add(newParam);
            }
            else
            {

            }
            listBoxMethod.Items.Clear();

            foreach (ParameterModel p in model.ParamList)
            {
                listBoxMethod.Items.Add(p.Identifier.ToString());
            }

            newParameterDialog.Dispose();

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void MethodDialog_Load(object sender, EventArgs e)
        {

        }
    }
}
