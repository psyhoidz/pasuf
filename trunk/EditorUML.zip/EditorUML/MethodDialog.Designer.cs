﻿namespace EditorUML
{
    partial class MethodDialog
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.textTypeMethod = new System.Windows.Forms.TextBox();
            this.CreateMethod = new System.Windows.Forms.Button();
            this.CancelMethod = new System.Windows.Forms.Button();
            this.listBoxMethod = new System.Windows.Forms.ListBox();
            this.AddParameter = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(170, 40);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(117, 20);
            this.textBox1.TabIndex = 0;
            this.textBox1.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(67, 43);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(38, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "Name:";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(49, 98);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(69, 13);
            this.label2.TabIndex = 2;
            this.label2.Text = "Return Type:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(167, 152);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(77, 13);
            this.label3.TabIndex = 3;
            this.label3.Text = "Parameter List:";
            // 
            // textTypeMethod
            // 
            this.textTypeMethod.Location = new System.Drawing.Point(170, 98);
            this.textTypeMethod.Name = "textTypeMethod";
            this.textTypeMethod.Size = new System.Drawing.Size(119, 20);
            this.textTypeMethod.TabIndex = 4;
            this.textTypeMethod.TextChanged += new System.EventHandler(this.textBox2_TextChanged);
            // 
            // CreateMethod
            // 
            this.CreateMethod.Location = new System.Drawing.Point(257, 302);
            this.CreateMethod.Name = "CreateMethod";
            this.CreateMethod.Size = new System.Drawing.Size(123, 23);
            this.CreateMethod.TabIndex = 5;
            this.CreateMethod.Text = "CreateMethod";
            this.CreateMethod.UseVisualStyleBackColor = true;
            this.CreateMethod.Click += new System.EventHandler(this.CreateMethod_Click);
            // 
            // CancelMethod
            // 
            this.CancelMethod.Location = new System.Drawing.Point(422, 302);
            this.CancelMethod.Name = "CancelMethod";
            this.CancelMethod.Size = new System.Drawing.Size(114, 22);
            this.CancelMethod.TabIndex = 6;
            this.CancelMethod.Text = "Cancel";
            this.CancelMethod.UseVisualStyleBackColor = true;
            this.CancelMethod.Click += new System.EventHandler(this.CancelMethod_Click);
            // 
            // listBoxMethod
            // 
            this.listBoxMethod.FormattingEnabled = true;
            this.listBoxMethod.Location = new System.Drawing.Point(170, 168);
            this.listBoxMethod.Name = "listBoxMethod";
            this.listBoxMethod.Size = new System.Drawing.Size(241, 95);
            this.listBoxMethod.TabIndex = 7;
            this.listBoxMethod.SelectedIndexChanged += new System.EventHandler(this.listBox1_SelectedIndexChanged);
            // 
            // AddParameter
            // 
            this.AddParameter.Location = new System.Drawing.Point(25, 164);
            this.AddParameter.Name = "AddParameter";
            this.AddParameter.Size = new System.Drawing.Size(122, 29);
            this.AddParameter.TabIndex = 8;
            this.AddParameter.Text = "Add Parameter";
            this.AddParameter.UseVisualStyleBackColor = true;
            this.AddParameter.Click += new System.EventHandler(this.AddParameter_Click);
            // 
            // MethodDialog
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(558, 339);
            this.Controls.Add(this.AddParameter);
            this.Controls.Add(this.listBoxMethod);
            this.Controls.Add(this.CancelMethod);
            this.Controls.Add(this.CreateMethod);
            this.Controls.Add(this.textTypeMethod);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.textBox1);
            this.Name = "MethodDialog";
            this.Text = "MethodDialog";
            this.Load += new System.EventHandler(this.MethodDialog_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox textTypeMethod;
        private System.Windows.Forms.Button CreateMethod;
        private System.Windows.Forms.Button CancelMethod;
        private System.Windows.Forms.ListBox listBoxMethod;
        private System.Windows.Forms.Button AddParameter;
    }
}